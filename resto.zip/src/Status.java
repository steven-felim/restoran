public enum Status{
    AVAILABLE, BOOKED, RESCHEDULED;
}