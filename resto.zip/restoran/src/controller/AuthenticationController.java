package controller;

public class AuthenticationController {
	public boolean login(String name, String password) {
		return true;
	}
	public void logout() {
	    
	}
}
