package model.enums;

public enum RoomType {
    REGULAR, OUTDOOR, VIP;
}
