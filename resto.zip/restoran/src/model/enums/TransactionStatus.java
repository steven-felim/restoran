package model.enums;

public enum TransactionStatus {
	PENDING, SUCCESS
}
