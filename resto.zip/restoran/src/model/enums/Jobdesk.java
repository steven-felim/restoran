package model.enums;

public enum Jobdesk {
	CASHIER, CHEF, WAITER, DELIVERYMAN
}
