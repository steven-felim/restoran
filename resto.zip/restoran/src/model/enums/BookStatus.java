package model.enums;

public enum BookStatus {
    AVAILABLE,
    BOOKED;
}
