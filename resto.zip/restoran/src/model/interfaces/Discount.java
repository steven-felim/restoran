package model.interfaces;

public interface Discount {
	double applyDiscount(double price);
}
